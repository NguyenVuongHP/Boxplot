from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.shapes import MSO_SHAPE_TYPE
import os
from typing import List, Callable
from controller.workstatus import Status
from controller.setting import Setting
import pandas as pd
from pptx.enum.text import PP_ALIGN


class ImageEmbedPPTX:

    callbackMessageThrower: Callable[[str], None] = None
    PPTX_TEMPLATE = 'Template_Report.pptx'
    PPTX_OUTPUT_NAME = 'Report'
    FIXED_TEXT_BOX_SHAPE_HEIGHT = 0.5
    LIST_IMAGE_FILEPATHS: List[str] = Status.LIST_FIGURE_IMAGES

    """
    GRAPH AREA IN SLIDE: area to attach external image to it.
    The attached image will be centered in the area (horizontally and vertically)
    Below positioning is based on the Top, Left corner of the slide as (0, 0) coordinate
    """
    GRAPH_TOP_MARGIN = Inches(
        1.75)  # Distance from top edge of Slide to Graph area
    # Distance from bottom edge of Slide to Graph area
    GRAPH_BOT_MARGIN = Inches(0.25)
    # Distance from left edge of Slide to Graph area
    GRAPH_LEFT_MARGIN = Inches(0.15)
    # Distance from right edge of Slide to Graph area
    GRAPH_RIGHT_MARGIN = Inches(0.15)

    SLIDE_WIDTH = 0  # Initialize only, change value after loading Template file
    SLIDE_HEIGHT = 0  # Initialize only, change value after loading Template file
    GRAPH_WIDTH = 0  # Initialize only, change value after loading Template file
    GRAPH_HEIGHT = 0  # Initialize only, change value after loading Template file

    def __init__(self):
        # check file existence
        self.pptx: Presentation = None

        if not os.path.exists(self.PPTX_TEMPLATE):
            # print(f'File {self.PPTX_FILENAME} not found.')
            return
        try:
            self.pptx = Presentation(self.PPTX_TEMPLATE)
        except:
            print(f'Failed to open Template file {
                  self.PPTX_TEMPLATE} for exporting image to.')
            self.pptx = None
            return

        # self.slide_width = self.pptx.slide_width
        # self.slide_height = self.pptx.slide_height
        ImageEmbedPPTX.SLIDE_HEIGHT = self.pptx.slide_height
        ImageEmbedPPTX.SLIDE_WIDTH = self.pptx.slide_width
        ImageEmbedPPTX.GRAPH_HEIGHT = ImageEmbedPPTX.SLIDE_HEIGHT - \
            ImageEmbedPPTX.GRAPH_TOP_MARGIN - ImageEmbedPPTX.GRAPH_BOT_MARGIN
        ImageEmbedPPTX.GRAPH_WIDTH = ImageEmbedPPTX.SLIDE_WIDTH - \
            ImageEmbedPPTX.GRAPH_LEFT_MARGIN - ImageEmbedPPTX.GRAPH_RIGHT_MARGIN

    def clearAllShapes(self) -> None:
        if self.pptx is None:
            return

        for slide in self.pptx.slides:
            # Remove the old figures
            shapes = slide.shapes
            for shape in shapes:
                match shape.shape_type:
                    case MSO_SHAPE_TYPE.GROUP | MSO_SHAPE_TYPE.PICTURE | MSO_SHAPE_TYPE.TABLE:
                        shapes.element.remove(shape.element)

    @staticmethod
    def getImageScaleVal(
            from_height: int,
            from_width: int,
            to_height: int,
            to_width: int) -> float:
        # scale figure size to max fit with max_width and max_height
        width_scale = to_width / from_width
        height_scale = to_height / from_height
        final_scale = min(width_scale, height_scale)
        return final_scale

    def exportImages2PPTX(self) -> None:
        if len(self.LIST_IMAGE_FILEPATHS) == 0:
            return
        if self.pptx is None:
            return

        # Đọc file Plot Config.csv để lấy tên các Figure
        try:
            plot_config = pd.read_csv(Setting.LOCAL_FIGURECONFIG_FILENAME)
            # Lọc các Figure có To Plot = Yes và lấy tên Figure duy nhất
            plot_config = plot_config[plot_config['To Plot'] == 'Yes']
            figure_titles = plot_config['Figure'].unique()
            self.callbackMessageThrower(f"Đọc được {len(figure_titles)} tiêu đề từ Plot Config")
        except Exception as e:
            self.callbackMessageThrower(f"Không thể đọc file Plot Config.csv: {str(e)}")
            return

        # Lấy slide template từ slide đầu tiên
        if len(self.pptx.slides) > 0:
            template_slide = self.pptx.slides[0]
        else:
            self.callbackMessageThrower("Template không có slide nào")
            return

        # Xóa tất cả các slide hiện có trừ slide template
        xml_slides = self.pptx.slides._sldIdLst
        slides = list(xml_slides)
        for slide in slides[1:]:
            xml_slides.remove(slide)

        i = 0
        for img in self.LIST_IMAGE_FILEPATHS:
            # Duplicate slide template bằng cách sử dụng layout của nó
            new_slide = self.pptx.slides.add_slide(template_slide.slide_layout)
            
            # Copy tất cả shapes từ template (trừ title)
            for shape in template_slide.shapes:
                if shape.has_text_frame and shape.text.strip().lower() == "title":
                    continue
                    
                # Copy vị trí và kích thước
                left = shape.left
                top = shape.top
                width = shape.width
                height = shape.height
                
                if shape.has_text_frame:
                    # Copy text shape
                    new_shape = new_slide.shapes.add_textbox(left, top, width, height)
                    new_shape.text_frame.text = shape.text_frame.text
                    
                    # Copy định dạng text
                    for idx, p in enumerate(shape.text_frame.paragraphs):
                        if idx < len(new_shape.text_frame.paragraphs):
                            new_p = new_shape.text_frame.paragraphs[idx]
                            new_p.alignment = p.alignment
                            if p.runs:
                                new_p.font.name = p.runs[0].font.name
                                new_p.font.size = p.runs[0].font.size
                                new_p.font.bold = p.runs[0].font.bold
                                new_p.font.italic = p.runs[0].font.italic
                
                elif hasattr(shape, 'shape_type'):
                    # Copy các shapes khác
                    if shape.shape_type == MSO_SHAPE_TYPE.AUTO_SHAPE:
                        new_shape = new_slide.shapes.add_shape(
                            shape.auto_shape_type, left, top, width, height
                        )
                        # Copy fill
                        if hasattr(shape, 'fill'):
                            if shape.fill.type is not None:
                                new_shape.fill.solid()
                                if hasattr(shape.fill.fore_color, 'rgb'):
                                    new_shape.fill.fore_color.rgb = shape.fill.fore_color.rgb
                        
                        # Copy line
                        if hasattr(shape, 'line'):
                            if hasattr(shape.line, 'color') and shape.line.color.type is not None:
                                new_shape.line.color.rgb = shape.line.color.rgb
                            if hasattr(shape.line, 'width'):
                                new_shape.line.width = shape.line.width

            # Thêm tiêu đề mới vào góc trái trên
            if i < len(figure_titles):
                title_shape = new_slide.shapes.add_textbox(
                    left=Inches(0.2),      # Giảm khoảng cách từ lề trái
                    top=Inches(0.2),       # Giảm khoảng cách từ lề trên
                    width=Inches(8),       # Giảm chiều rộng để không đè lên các phần khác
                    height=Inches(0.4)     # Giảm chiều cao
                )
                title_frame = title_shape.text_frame
                title_frame.text = figure_titles[i]
                
                # Định dạng font cho tiêu đề
                title_paragraph = title_frame.paragraphs[0]
                title_paragraph.font.size = Pt(16)  # Giảm size chữ
                title_paragraph.font.name = 'Arial'
                title_paragraph.font.bold = True
                title_paragraph.alignment = PP_ALIGN.LEFT
                
                # Đặt margin cho text trong textbox
                title_frame.margin_left = 0
                title_frame.margin_right = 0
                title_frame.margin_top = 0
                title_frame.margin_bottom = 0

            # Thêm và căn chỉnh hình ảnh
            added_img = new_slide.shapes.add_picture(
                image_file=img, left=0, top=0)

            # resize the added image to fit Graph area
            img_scale = ImageEmbedPPTX.getImageScaleVal(
                from_height=int(added_img.height),
                from_width=int(added_img.width),
                to_height=int(ImageEmbedPPTX.GRAPH_HEIGHT),
                to_width=int(ImageEmbedPPTX.GRAPH_WIDTH))

            added_img.width = int(added_img.width * img_scale)
            added_img.height = int(added_img.height * img_scale)

            # align picture to the center horizontally and vertically
            added_img.left = int(ImageEmbedPPTX.GRAPH_LEFT_MARGIN +
                               (ImageEmbedPPTX.GRAPH_WIDTH - added_img.width) / 2)
            added_img.top = int(ImageEmbedPPTX.GRAPH_TOP_MARGIN +
                              (ImageEmbedPPTX.GRAPH_HEIGHT - added_img.height) / 2)

            # Đưa hình ảnh xuống dưới cùng
            added_img.zorder = 0

            i += 1

        # Xóa slide template
        xml_slides.remove(slides[0])

        # Save the PPT
        pptx_output_file = Setting.OUTPUT_DIR + '\\' + self.PPTX_OUTPUT_NAME + '.pptx'
        try:
            self.pptx.save(pptx_output_file)
            self.callbackMessageThrower(
                f'Successfully exported Graph to file: {pptx_output_file}')
        except Exception as e:
            try:
                self.callbackMessageThrower(str(e))
            except:
                pass
            raise Exception(e)
