class PlotConfig:

    def __init__(
        self,
        name: str = "",
        title: str = "",
        lowerspec: float = -1.0,
        upperspec: float = -1.0,
        to_plot: bool = False
    ) -> None:

        self.item_name = name
        self.title = title
        self.to_plot = to_plot

        if lowerspec != lowerspec:
            self.lowerspec = None
        else:
            self.lowerspec = lowerspec

        if upperspec != upperspec:
            self.upperspec = None
        else:
            self.upperspec = upperspec
